exports.modules = [
  './js/_intro-mdb-pro.js',
  './js/vendor/jquery.easing.js',
  './js/vendor/velocity.js',
  './js/vendor/chart.js',
  './js/vendor/wow.js',
  './js/dist/scrolling-navbar.js',
  './js/vendor/waves.js',
  './js/dist/forms-free.js',
  './js/dist/preloading.js',
  './js/dist/cards.js',
  './js/dist/character-counter.js',
  './js/vendor/toastr.js',
  './js/dist/smooth-scroll.js',
  './js/dist/dropdown.js',
  './js/dist/buttons.js',
  './js/dist/sidenav.js',
  './js/dist/collapsible.js',
  './js/vendor/jquery.easypiechart.js',
  './js/dist/range-input.js',
  './js/dist/file-input.js',
  './js/dist/material-select.js',
  './js/vendor/picker.js',
  './js/vendor/picker-date.js',
  './js/vendor/picker-time.js',
  './js/vendor/lightbox.js',
  './js/dist/sticky.js',
  './js/vendor/scrollbar.js',
  './js/dist/chips.js',
  './js/vendor/ofi.js',
  './js/vendor/jarallax.js',
  './js/vendor/jarallax-video.js',
  './js/dist/mdb-autocomplete.js',
  './js/vendor/enhanced-modals.js',
  './js/dist/treeview.js',
  './js/vendor/bs-custom-file-input.js',
  // './js/vendor/addons/jquery.zmd.hierarchical-display.js'
  // './js/vendor/addons/masonry.pkgd.min.js',
  // './js/vendor/addons/imagesloaded.pkgd.min.js'
  // './js/vendor/addons/datatables.js'
  // './js/vendor/addons-pro/timeline.js',
  // './js/vendor/addons-pro/steppers.js'
  // './js/vendor/addons-pro/multi-range.js'
  // './js/vendor/addons-pro/rating.js'
  // './js/vendor/addons-pro/chat.js'
];
